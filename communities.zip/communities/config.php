<?php 

# This is the database connection data
define('SERVER', 'localhost');
define('USERNAME', 'root');
define('PASSWORD', '');
define('DATABASENAME', 'communities');


?>